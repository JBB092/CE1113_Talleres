SUMMARY = "Biblioteca liboperaciones"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = "file://operaciones.c file://operaciones.h file://CMakeLists.txt"
S = "${WORKDIR}"

inherit cmake

# Excepciones de QA que ya superamos
FILES_SOLIBSDEV = ""
FILES:${PN} += "${libdir}/liboperaciones.so"
INSANE_SKIP:${PN}-dev += "dev-elf"
INSANE_SKIP:${PN} += "dev-so"
