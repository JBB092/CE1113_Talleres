#ifndef OPERACIONES_H
#define OPERACIONES_H

float op_suma ( float a, float b ) ;
float op_resta ( float a, float b ) ;
float op_mult ( float a, float b ) ;
float op_div ( float a, float b ) ;
float op_sqrt ( float a ) ;

#endif /* OPERACIONES_H */
